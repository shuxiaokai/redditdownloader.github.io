r = window.r || {}
