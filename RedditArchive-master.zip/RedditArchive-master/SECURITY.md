![white hat trophy](https://b.thumbs.redditmedia.com/n0_7BYpCg_RYB1j7.png)

Like all pieces of software, reddit has bugs &ndash; and it always will. Some
of them will take the form of security vulnerabilities.

If you find a security vulnerability in reddit, please privately report it to
[security@reddit.com](mailto:security@reddit.com). We'll get back to you ASAP,
usually within 24 hours.

Once the issue is fixed, if you provide your reddit username, we'll credit your
account with a [whitehat](https://www.reddit.com/wiki/whitehat) trophy.

Thank you and good hunting.
